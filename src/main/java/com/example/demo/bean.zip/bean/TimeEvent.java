package com.example.demo.bean;

import lombok.Data;

/**
 * 时间事件 时钟事件？
 */
@Data
public class TimeEvent {
	int time;
	String[] events;
}
