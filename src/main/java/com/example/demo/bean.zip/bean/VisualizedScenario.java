package com.example.demo.bean;

import lombok.Data;

/**
 * 可视化情景
 */
@Data
public class VisualizedScenario {
	int conflictTime;
	TimeEvent timeEvents;
}
