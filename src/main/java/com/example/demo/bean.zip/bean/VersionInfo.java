package com.example.demo.bean;

import lombok.Data;

/**
 * 版本信息 ？
 */
@Data
public class VersionInfo {
	private String versionId;
	private String time;
	private String command;
}
